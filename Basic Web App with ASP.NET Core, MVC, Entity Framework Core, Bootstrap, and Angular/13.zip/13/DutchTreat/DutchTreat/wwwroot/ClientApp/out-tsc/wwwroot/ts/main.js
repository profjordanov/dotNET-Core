var shopper = new StoreCustomer("Shawn", "Wildermuth");
shopper.showName();
//# sourceMappingURL=main.js.map