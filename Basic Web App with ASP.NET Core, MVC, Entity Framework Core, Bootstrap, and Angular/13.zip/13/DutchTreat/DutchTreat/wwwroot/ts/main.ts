﻿

let shopper = new StoreCustomer("Shawn", "Wildermuth");
shopper.showName(); 