﻿import { Component } from "@angular/core";

@Component({
  selector: "the-shop",
  templateUrl: "shop.component.html"
})
export class Shop {

}